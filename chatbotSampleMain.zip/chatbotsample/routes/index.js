const express = require('express');
const router = express.Router();

// Import temp store for testing
const tempStore = require('./temp-store');

// In-memory storage for business and inventory data
// In a real application, you would use a database
let businessData = {};
let inventoryData = [];

// Setting initial data for easier testing
const useTestData = false;  // Set to false to disable test data
if (useTestData) {
  businessData = tempStore.businessData;
  inventoryData = tempStore.inventoryData;
}

// Home page - redirect to business form
router.get('/', (req, res) => {
  // If using test data, you can skip to the chatbot directly
  if (useTestData) {
    res.redirect('/chatbot');
  } else {
    res.render('business-form');
  }
});

// Business form page
router.get('/business-form', (req, res) => {
  res.render('business-form');
});

// Handle business form submission
router.post('/submit-business', (req, res) => {
  businessData = req.body;
  res.redirect('/inventory-form');
});

// Inventory form page
router.get('/inventory-form', (req, res) => {
  res.render('inventory-form', { businessData });
});

// Handle inventory form submission
router.post('/submit-inventory', (req, res) => {
  // Process inventory data from form
  const items = req.body.items || [];
  
  // If single item, convert to array
  if (!Array.isArray(items)) {
    inventoryData = [items];
  } else {
    inventoryData = items;
  }
  
  res.redirect('/whatsapp-scan');
});

// WhatsApp scan page
router.get('/whatsapp-scan', (req, res) => {
  res.render('whatsapp-scan');
});

// Chatbot page
router.get('/chatbot', (req, res) => {
  // Pass the data as JSON strings to be used with the hidden fields
  res.render('chatbot', { 
    businessDataJSON: JSON.stringify(businessData || {}),
    inventoryDataJSON: JSON.stringify(inventoryData || [])
  });
});

// API endpoint for chatbot interaction
router.post('/api/chat', async (req, res) => {
  try {
    const { message, threadId } = req.body;
    
    // Import the chatbot module
    const chatbot = require('../models/chatbot');
    
    // Get response from chatbot
    const response = await chatbot.getResponse(message, threadId, businessData, inventoryData);
    
    res.json({ response });
  } catch (error) {
    console.error('Error in chat API:', error);
    res.status(500).json({ error: 'An error occurred while processing your request' });
  }
});

// For testing: Get current business data
router.get('/api/business-data', (req, res) => {
  res.json(businessData);
});

// For testing: Get current inventory data
router.get('/api/inventory-data', (req, res) => {
  res.json(inventoryData);
});

module.exports = router;