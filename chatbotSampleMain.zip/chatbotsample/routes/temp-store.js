// A simple module to store business and inventory data
// This allows you to test without filling out forms each time

// Default business data for testing
const businessData = {
    businessName: "Coffee Haven",
    businessType: "café",
    description: "A cozy coffee shop with a variety of premium coffee beans and pastries.",
    address: "123 Main Street, Anytown, USA",
    contactPhone: "(555) 123-4567",
    contactEmail: "info@coffeehaven.example",
    openingHours: "Mon-Fri: 7AM-8PM, Sat-Sun: 8AM-9PM"
  };
  
  // Default inventory data for testing
  const inventoryData = [
    {
      name: "House Blend Coffee",
      description: "Our signature medium roast coffee with balanced flavor.",
      price: "3.99",
      quantity: "100",
      category: "Coffee"
    },
    {
      name: "Espresso Machine",
      description: "Professional grade home espresso machine.",
      price: "299.99",
      quantity: "10",
      category: "Equipment"
    },
    {
      name: "Chocolate Croissant",
      description: "Buttery croissant filled with chocolate.",
      price: "4.50",
      quantity: "25",
      category: "Pastry"
    },
    {
      name: "Cold Brew Kit",
      description: "Make cold brew coffee at home.",
      price: "24.99",
      quantity: "15",
      category: "Equipment"
    }
  ];
  
  module.exports = {
    businessData,
    inventoryData
  };