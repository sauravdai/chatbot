document.addEventListener('DOMContentLoaded', function() {
    const chatForm = document.getElementById('chatForm');
    const userMessageInput = document.getElementById('userMessage');
    const chatMessages = document.getElementById('chatMessages');
    
    // Generate a unique thread ID for this chat session
    const threadId = generateThreadId();
    
    // Event listener for sending messages
    chatForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const messageText = userMessageInput.value.trim();
      if (messageText === '') return;
      
      // Add user message to chat
      addMessageToChat('user', messageText);
      
      // Clear input field
      userMessageInput.value = '';
      
      // Show typing indicator
      const typingIndicator = addTypingIndicator();
      
      // Send message to server
      fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: messageText,
          threadId: threadId
        })
      })
      .then(response => response.json())
      .then(data => {
        // Remove typing indicator
        chatMessages.removeChild(typingIndicator);
        
        // Add assistant response to chat
        addMessageToChat('assistant', data.response);
        
        // Scroll to bottom
        scrollToBottom();
      })
      .catch(error => {
        console.error('Error:', error);
        chatMessages.removeChild(typingIndicator);
        addMessageToChat('assistant', 'Sorry, there was an error processing your request.');
      });
    });
    
    // Function to add a message to the chat
    function addMessageToChat(sender, message) {
      const messageDiv = document.createElement('div');
      messageDiv.className = `message ${sender}-message`;
      
      const messageContent = document.createElement('div');
      messageContent.className = 'message-content';
      
      const messageParagraph = document.createElement('p');
      messageParagraph.textContent = message;
      
      messageContent.appendChild(messageParagraph);
      messageDiv.appendChild(messageContent);
      chatMessages.appendChild(messageDiv);
      
      scrollToBottom();
    }
    
    // Function to add typing indicator
    function addTypingIndicator() {
      const typingDiv = document.createElement('div');
      typingDiv.className = 'message assistant-message typing-indicator';
      
      const typingContent = document.createElement('div');
      typingContent.className = 'message-content';
      
      const typingDots = document.createElement('div');
      typingDots.className = 'typing-dots';
      typingDots.innerHTML = '<span></span><span></span><span></span>';
      
      typingContent.appendChild(typingDots);
      typingDiv.appendChild(typingContent);
      chatMessages.appendChild(typingDiv);
      
      scrollToBottom();
      
      return typingDiv;
    }
    
    // Function to scroll chat to bottom
    function scrollToBottom() {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to generate a thread ID
    function generateThreadId() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    }
    
    // Add CSS for typing indicator
    const style = document.createElement('style');
    style.textContent = `
      .typing-dots {
        display: flex;
        gap: 4px;
        padding: 6px 0;
      }
      
      .typing-dots span {
        width: 8px;
        height: 8px;
        background-color: #bbb;
        border-radius: 50%;
        animation: typingAnimation 1.4s infinite ease-in-out both;
      }
      
      .typing-dots span:nth-child(1) {
        animation-delay: 0s;
      }
      
      .typing-dots span:nth-child(2) {
        animation-delay: 0.2s;
      }
      
      .typing-dots span:nth-child(3) {
        animation-delay: 0.4s;
      }
      
      @keyframes typingAnimation {
        0%, 80%, 100% { transform: scale(0.6); }
        40% { transform: scale(1); }
      }
    `;
    
    document.head.appendChild(style);
  });