document.addEventListener('DOMContentLoaded', function() {
    const progressBar = document.querySelector('.progress-bar');
    const statusMessage = document.getElementById('statusMessage');
    const continueBtn = document.getElementById('continueBtn');
    const simulateScanBtn = document.getElementById('simulateScanBtn');
    
    // In a real app, this would connect to WhatsApp Web API
    // For this demo, we'll simulate the scanning process
    simulateScanBtn.addEventListener('click', function() {
      simulateScanBtn.disabled = true;
      
      // Simulate progress
      let progress = 0;
      const interval = setInterval(function() {
        progress += 5;
        progressBar.style.width = progress + '%';
        progressBar.setAttribute('aria-valuenow', progress);
        progressBar.textContent = progress + '%';
        
        // Update status message based on progress
        if (progress < 25) {
          statusMessage.textContent = 'Initiating connection...';
        } else if (progress < 50) {
          statusMessage.textContent = 'Scanning QR code...';
        } else if (progress < 75) {
          statusMessage.textContent = 'Verifying account...';
        } else if (progress < 100) {
          statusMessage.textContent = 'Finalizing connection...';
        } else {
          statusMessage.textContent = 'Connected successfully!';
          clearInterval(interval);
          
          // Show the continue button
          continueBtn.style.display = 'block';
          simulateScanBtn.style.display = 'none';
        }
      }, 200);
    });
  });