// This script handles additional functionality for the business form
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    
    // Basic form validation
    form.addEventListener('submit', function(e) {
      const businessName = document.getElementById('businessName').value.trim();
      const businessType = document.getElementById('businessType').value;
      const description = document.getElementById('description').value.trim();
      
      // Simple validation example (can be expanded as needed)
      if (businessName === '' || businessType === '' || description === '') {
        e.preventDefault();
        alert('Please fill in all required fields');
      }
    });
    
    // You can add more interactive features here if needed
  });