document.addEventListener('DOMContentLoaded', function() {
    const inventoryItemsContainer = document.getElementById('inventoryItems');
    const addItemBtn = document.getElementById('addItem');
    const removeItemBtn = document.getElementById('removeItem');
    
    let itemCount = 1;
    
    // Add a new inventory item
    addItemBtn.addEventListener('click', function() {
      itemCount++;
      
      const newItem = document.createElement('div');
      newItem.className = 'inventory-item mb-4 p-3 border rounded';
      newItem.innerHTML = `
        <h4 class="mb-3">Item #${itemCount}</h4>
        
        <div class="mb-3">
          <label for="items[${itemCount-1}][name]" class="form-label">Item Name</label>
          <input type="text" class="form-control" name="items[${itemCount-1}][name]" required>
        </div>
        
        <div class="mb-3">
          <label for="items[${itemCount-1}][description]" class="form-label">Description</label>
          <textarea class="form-control" name="items[${itemCount-1}][description]" rows="2"></textarea>
        </div>
        
        <div class="row">
          <div class="col-md-4 mb-3">
            <label for="items[${itemCount-1}][price]" class="form-label">Price ($)</label>
            <input type="number" step="0.01" class="form-control" name="items[${itemCount-1}][price]" required>
          </div>
          
          <div class="col-md-4 mb-3">
            <label for="items[${itemCount-1}][quantity]" class="form-label">Quantity</label>
            <input type="number" class="form-control" name="items[${itemCount-1}][quantity]" required>
          </div>
          
          <div class="col-md-4 mb-3">
            <label for="items[${itemCount-1}][category]" class="form-label">Category</label>
            <input type="text" class="form-control" name="items[${itemCount-1}][category]">
          </div>
        </div>
      `;
      
      inventoryItemsContainer.appendChild(newItem);
      
      // Enable the remove button when we have more than one item
      if (itemCount > 1) {
        removeItemBtn.disabled = false;
      }
    });
    
    // Remove the last inventory item
    removeItemBtn.addEventListener('click', function() {
      if (itemCount > 1) {
        const inventoryItems = inventoryItemsContainer.getElementsByClassName('inventory-item');
        inventoryItemsContainer.removeChild(inventoryItems[inventoryItems.length - 1]);
        itemCount--;
        
        // Disable the remove button if only one item remains
        if (itemCount === 1) {
          removeItemBtn.disabled = true;
        }
      }
    });
  });