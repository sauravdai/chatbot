const {
    START,
    END,
    StateGraph,
    MemorySaver,
    MessagesAnnotation,
    Annotation
  } = require('@langchain/langgraph');
  const { ChatGoogleGenerativeAI } = require('@langchain/google-genai');
  const { ChatPromptTemplate } = require('@langchain/core/prompts');
  const { v4: uuidv4 } = require('uuid');
  
  // Create memory store for chat threads
  const memoryStore = new MemorySaver();
  
  // Initialize thread store to manage active thread IDs
  const threadStore = new Map();
  
  // Create the Google Gemini chat model
  const llm = new ChatGoogleGenerativeAI({
    apiKey: process.env.GOOGLE_API_KEY,
    modelName: 'gemini-1.5-flash', 
    temperature: 0.2,
  });
  llm.invoke("Hello, world!")
  
  // Define the prompt template for the chatbot
  const createPromptTemplate = (businessData, inventoryData) => {
    // Format the inventory data for the prompt
    const inventoryText = inventoryData.map(item => 
      `Item: ${item.name || 'Unnamed Item'}
       Description: ${item.description || 'N/A'}
       Price: $${item.price || 'N/A'}
       Quantity: ${item.quantity || 'N/A'}
       Category: ${item.category || 'N/A'}`
    ).join('\n\n');
  
    // Create the system message with business and inventory details
    const systemMessage = `You are a helpful customer service assistant for ${businessData.businessName || 'this business'}, which is a ${businessData.businessType || 'business'}.
  
  Business Information:
  - Description: ${businessData.description || 'Not provided'}
  - Address: ${businessData.address || 'Not provided'}
  - Contact Phone: ${businessData.contactPhone || 'Not provided'}
  - Contact Email: ${businessData.contactEmail || 'Not provided'}
  - Opening Hours: ${businessData.openingHours || 'Not provided'}
  
  Inventory Information:
  ${inventoryText || 'No inventory items available'}
  
  Your role is to help customers by answering questions about the business, providing information about products/inventory, handling basic inquiries, and being helpful and friendly. If a customer asks about something not in the inventory or about the business that you don't know, politely explain that you don't have that information.
  
  Always be professional, courteous, and provide accurate information based on the business and inventory details above.`;
  
    return ChatPromptTemplate.fromMessages([
      ["system", systemMessage],
      ["placeholder", "{messages}"]
    ]);
  };
  
  // A simple function to limit the number of messages (instead of using trimMessages)
  function limitMessages(messages, maxMessages = 10) {
    if (!Array.isArray(messages)) return messages;
    
    // Always keep system messages
    const systemMessages = messages.filter(msg => msg.role === 'system');
    
    // Get the latest non-system messages up to maxMessages
    const nonSystemMessages = messages
      .filter(msg => msg.role !== 'system')
      .slice(-maxMessages);
    
    // Combine them
    return [...systemMessages, ...nonSystemMessages];
  }
  
  // Create a chat graph for a specific business and inventory
  const createChatGraph = (businessData, inventoryData) => {
    // Define the State for the graph
    const GraphAnnotation = Annotation.Root({
      ...MessagesAnnotation.spec,
    });
  
    // Create the prompt template
    const promptTemplate = createPromptTemplate(businessData, inventoryData);
  
    // Define the function that calls the model
    const callModel = async (state) => {
      try {
        // Limit messages to prevent context window overflow
        const limitedMessages = limitMessages(state.messages, 10);
        
        // Generate prompt with limited messages
        const prompt = await promptTemplate.invoke({ messages: limitedMessages });
        
        // Get response from LLM
        const response = await llm.invoke(prompt);
        
        // Return the response to update state
        return { messages: [response] };
      } catch (error) {
        console.error('Error in callModel:', error);
        
        // Return a fallback response in case of error
        return { 
          messages: [{ 
            role: 'assistant', 
            content: "I'm sorry, I encountered an error. Please try again." 
          }] 
        };
      }
    };
  
    // Create the graph
    const workflow = new StateGraph(GraphAnnotation)
      .addNode("model", callModel)
      .addEdge(START, "model")
      .addEdge("model", END);
  
    // Compile the graph with memory
    return workflow.compile({ checkpointer: memoryStore });
  };
  
  // Function to get a response from the chatbot
  const getResponse = async (message, threadId, businessData, inventoryData) => {
    try {
      // Check if thread exists, create if not
      if (!threadStore.has(threadId)) {
        threadStore.set(threadId, createChatGraph(businessData, inventoryData));
      }
      
      // Get the chat graph for this thread
      const chatGraph = threadStore.get(threadId);
      
      // Config for message thread
      const config = { configurable: { thread_id: threadId } };
      
      // Prepare input message
      const input = {
        messages: [
          {
            role: "user",
            content: message
          }
        ]
      };
      
      // Get response
      const output = await chatGraph.invoke(input, config);
      
      // Return the last message (the assistant's response)
      const lastMessage = output.messages[output.messages.length - 1];
      return lastMessage.content;
    } catch (error) {
      console.error('Error in chatbot response:', error);
      return "I'm sorry, I encountered an error. Please try again.";
    }
  };
  
  module.exports = {
    getResponse
  };